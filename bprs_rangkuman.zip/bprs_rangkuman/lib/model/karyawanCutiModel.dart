class KaryawanCutiModel {
  int? karyawanId;
  String? tanggalMulai;
  String? tanggalSelesai;
  int? durasi;
  String? status;
  String? keterangan;
  String? gambar;
  String? jenisAbsen;
  String? tanggalPersetujuan;
  String? tanggalPengajuan;

  // int? id;

  KaryawanCutiModel({
    required this.karyawanId,
    required this.tanggalMulai,
    required this.tanggalSelesai,
    required this.durasi,
    required this.status,
    required this.keterangan,
    required this.gambar,
    required this.jenisAbsen,
    required this.tanggalPersetujuan,
    required this.tanggalPengajuan,
  });

  factory KaryawanCutiModel.fromJson(Map<String, dynamic> json) {
    return KaryawanCutiModel(
      karyawanId: json['id'],
      tanggalMulai: json['tanggal_mulai'],
      tanggalSelesai: json['tanggal_selesai'],
      durasi: json['durasi'],
      status: json['status'],
      keterangan: json['keterangan'],
      gambar: json['gambar'],
      jenisAbsen: json['jenis_absen'],
      tanggalPersetujuan: json['tanggal_persetujuan'],
      tanggalPengajuan: json['created_at'],
    );
  }
}
