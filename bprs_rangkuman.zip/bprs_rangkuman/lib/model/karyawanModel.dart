class KaryawanModel {
  int? karyawanId;
  String? noKaryawan;
  String? namaLengkap;
  int? departement;
  int? jabatan;
  String? shift;
  String? foto;
  String? password;
  String? email;
  String? telp;

  // int? id;

  KaryawanModel({
    required this.karyawanId,
    required this.noKaryawan,
    required this.namaLengkap,
    required this.departement,
    required this.jabatan,
    required this.shift,
    required this.foto,
    required this.password,
    required this.email,
    required this.telp,
  });

  factory KaryawanModel.fromJson(Map<String, dynamic> json) {
    return KaryawanModel(
      karyawanId: json['id'],
      noKaryawan: json['no_karyawan'],
      namaLengkap: json['nama_lengkap'],
      departement: json['departement_id'],
      jabatan: json['jabatan_id'],
      shift: json['nama_shift'],
      foto: json['foto'],
      password: json['password'],
      email: json['email'],
      telp: json['no_telp'],
    );
  }
}
