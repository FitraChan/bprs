class AbsensiModel {
  int? karyawanId;
  String? tanggal;
  String? jamMasuk;
  String? jamPulang;
  String? statusAbsensi;
  String? keterangan;

  // int? id;

  AbsensiModel({
    required this.karyawanId,
    required this.tanggal,
    required this.jamMasuk,
    required this.jamPulang,
    required this.statusAbsensi,
    required this.keterangan,
  });

  factory AbsensiModel.fromJson(Map<String, dynamic> json) {
    return AbsensiModel(
      karyawanId: json['id'],
      tanggal: json['tanggal'],
      jamMasuk: json['jam_masuk'],
      jamPulang: json['jam_pulang'],
      statusAbsensi: json['status_absensi'],
      keterangan: json['keterangan'],
    );
  }
}
