import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:bprs/network_utils/api.dart';

import 'package:bprs/screen/menu.dart';

import 'package:rflutter_alert/rflutter_alert.dart';

class Profil extends StatefulWidget {
  Profil({
    Key? key,
  }) : super(key: key);

  @override
  _ProfilState createState() => _ProfilState();
}

class _ProfilState extends State<Profil> {
  //  FirebaseMessaging messaging;

  String? name;
  String? _dropdownError;
  //String? noKaryawan;
  String? notificationText;
  String? base64Image;
  File? imageFile = null;
  String? _image = null;
  String status = '';
  String errMessage = 'Error Uploading Image';
  bool loadingSave = false;
  String? idDepartement;

  String? selectDept;
  String? jabatan;
  String? namaKaryawan;
  String? noKaryawan;
  String? departement;
  String? tglMasuk;
  String? pendidikan;
  String? gambarLoe;
  String? email;
  String? noHp;
  String statusKaryawan = '';
  String alamat = '';
  String reward = '';
  String punishment = '';
  TextEditingController password = TextEditingController();
  final TextEditingController confirmPassword = TextEditingController();
  final GlobalKey<FormState> _form = GlobalKey<FormState>();
  //late EmailAuth emailAuth;

//  TextEditingController? shift = TextEditingController();
  List dataDept2 = [];
  List names = [];
  List dataJab = [];

  List filteredNames = [];

  @override
  void initState() {
    selectDept = null;

    fetchAlbum();

    super.initState();
  }

  void fetchAlbum() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    var user = jsonDecode(localStorage.getString('user') ?? '');
    Map data = {
      'karyawan_id': user['id'],
    };
    // String _url = 'http://192.168.5.10/bprs_api/public/api/profil';
    String _url = 'https://absensi.mbcconsulting.id/api/profil';
    final response = await Network().getData_post(data, _url);

    var c = json.decode(response.body);

    if (response.statusCode == 200) {
      var b = c['absen'];
      var d = c['dept'];
      var e = c['jabt'];
      var f = c['pend'];
      var g = c['tgl_masuk'];

      //print(c['pend']);
      //  print(e);

      setState(() {
        namaKaryawan = b['nama_lengkap'] ?? "";
        noKaryawan = b['nik'] ?? "";
        gambarLoe = b['foto'] ?? "";
        idDepartement = d['nama_departement'];
        jabatan = e['nama_jabatan'];
        pendidikan = f['nama_pendidikan'] ?? "";
        tglMasuk = g;
        email = b['email'] ?? "";
        noHp = b['no_telp'] ?? "";
        statusKaryawan = b['sts_karyawan'] ?? "";
        alamat = b['alamat'] ?? "";
        reward = b['reward'] ?? "";
        punishment = b['punishment'] ?? "";
      });
    } else {
      throw Exception('Failed to load album');
    }
  }

  Container logo() {
    return Container(
      margin: const EdgeInsets.only(top: 25),
      width: 130,
      height: 40,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        // color: Colors.white,

        image: const DecorationImage(
          image: AssetImage('images/logo_bprs.jpg'),
          fit: BoxFit.fill,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => Menu(
                      i: 0,
                    )),
          );
          return Future.value(true);
        },
        child: Scaffold(
          backgroundColor: Color.fromARGB(255, 247, 249, 250),
          body: SingleChildScrollView(
            child: Column(children: <Widget>[
              logo(),
              dataProfil(),
            ]),
          ),
        ));
  }

  Container dataProfil() {
    final border = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10.0),
    );

    // if (idDepartement != null && selectDept == null) {
    //   selectDept = idDepartement;
    // }

    var sts = "";

    if (statusKaryawan == "T") {
      sts = "Tetap";
    } else if (statusKaryawan == "P") {
      sts = "Percobaan";
    } else if (statusKaryawan == "M") {
      sts = "Magang";
    } else {
      sts = "Kontrak";
    }
    return Container(
        padding: const EdgeInsets.only(left: 20, right: 20),
        child: Column(
          children: [
            Container(
                child: gambarLoe != ""
                    ? Container(
                        width: 150,
                        height: 150,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            image: DecorationImage(
                                fit: BoxFit.fill,
                                image: NetworkImage(gambarLoe ?? ""))),
                        margin: const EdgeInsets.only(top: 10.0),
                        // gambarLoe != ""
                        //     ? CachedNetworkImage(
                        //         imageUrl: gambarLoe ?? "",
                        //         placeholder: (context, url) =>
                        //             CircularProgressIndicator(),
                        //         errorWidget: (context, url, error) =>
                        //             Icon(Icons.error),
                        //         width: 150,
                        //         height: 150,
                        //       )
                        //     : const Text(
                        //         'no Image',
                        //         style:
                        //             TextStyle(color: Colors.black, fontSize: 14),
                        //         textAlign: TextAlign.center,
                        //       )
                      )
                    : const Text(
                        'no Image',
                        style: TextStyle(color: Colors.black, fontSize: 14),
                        textAlign: TextAlign.center,
                      )),
            Container(
              margin: EdgeInsets.only(top: 10),
              child: Table(
                // defaultVerticalAlignment:
                //     TableCellVerticalAlignment.middle,
                columnWidths: const {
                  0: FlexColumnWidth(2),
                  1: FlexColumnWidth(4),
                },
                //textDirection: TextDirection.ltr,
                border: TableBorder.symmetric(
                    inside: BorderSide(width: 1, color: Colors.grey.shade300),
                    outside: BorderSide(width: 1, color: Colors.grey.shade300)),
                defaultColumnWidth: const FixedColumnWidth(150),
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,

                children: [
                  TableRow(
                      decoration: BoxDecoration(color: Colors.grey[200]),
                      children: [
                        Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Text(
                                'Nama Karyawan',
                                style: TextStyle(
                                    fontSize: 17, fontWeight: FontWeight.bold),
                              ),
                            ]),
                        Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // ignore: unrelated_type_equality_checks
                              Text(
                                namaKaryawan.toString(),
                                style: TextStyle(
                                  fontSize: 17,
                                  //     fontWeight: FontWeight.bold,
                                ),
                              ),
                            ]),
                      ]),
                  TableRow(children: [
                    const Text(
                      "Departement",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 17,
                      ),
                    ),
                    Text(
                      idDepartement.toString(),
                      style: TextStyle(
                        fontSize: 17,
                        //   fontWeight: FontWeight.bold,
                      ),
                    ),
                  ]),
                  TableRow(
                      decoration: BoxDecoration(color: Colors.grey[200]),
                      children: [
                        const Text(
                          "Tanggal Masuk",
                          style: TextStyle(
                              fontSize: 17, fontWeight: FontWeight.bold),
                        ),
                        // ignore: unrelated_type_equality_checks
                        Text(
                          tglMasuk.toString(),
                          style: TextStyle(
                            fontSize: 17,
                            //  fontWeight: FontWeight.bold,
                          ),
                        ),
                      ]),
                  TableRow(
                      decoration: BoxDecoration(color: Colors.white),
                      children: [
                        const Text(
                          "Jabatan",
                          style: TextStyle(
                              fontSize: 17, fontWeight: FontWeight.bold),
                        ),
                        Text(jabatan.toString(),
                            style: TextStyle(
                              fontSize: 17,
                              //   fontWeight: FontWeight.bold,
                            )),
                      ]),
                  TableRow(
                      decoration: BoxDecoration(color: Colors.grey[200]),
                      children: [
                        const Text(
                          "Pendidikan Terakhir",
                          style: TextStyle(
                              fontSize: 17, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          pendidikan.toString(),
                          style: TextStyle(
                            fontSize: 17,
                            // fontWeight: FontWeight.bold,
                          ),
                        ),
                      ]),
                  TableRow(
                      decoration: BoxDecoration(color: Colors.white),
                      children: [
                        const Text(
                          "No Telp",
                          style: TextStyle(
                              fontSize: 17, fontWeight: FontWeight.bold),
                        ),
                        // ignore: unrelated_type_equality_checks
                        Text(
                          noHp.toString(),
                          style: TextStyle(
                            fontSize: 17,
                            //fontWeight: FontWeight.bold,
                          ),
                        ),
                      ]),
                  TableRow(
                      decoration: BoxDecoration(color: Colors.grey[200]),
                      children: [
                        const Text(
                          "Email",
                          style: TextStyle(
                              fontSize: 17, fontWeight: FontWeight.bold),
                        ),
                        // ignore: unrelated_type_equality_checks
                        Text(
                          email.toString(),
                          style: TextStyle(
                            fontSize: 17,
                            // fontWeight: FontWeight.bold,
                          ),
                        ),
                      ]),
                  TableRow(
                      decoration: BoxDecoration(color: Colors.white),
                      children: [
                        const Text(
                          "Status Karyawan",
                          style: TextStyle(
                              fontSize: 17, fontWeight: FontWeight.bold),
                        ),
                        // ignore: unrelated_type_equality_checks
                        Text(
                          sts.toString(),
                          style: TextStyle(
                            fontSize: 17,
                            //fontWeight: FontWeight.bold,
                          ),
                        ),
                      ]),
                  TableRow(
                      decoration: BoxDecoration(color: Colors.grey[200]),
                      children: [
                        const Text(
                          "Reward",
                          style: TextStyle(
                              fontSize: 17, fontWeight: FontWeight.bold),
                        ),
                        // ignore: unrelated_type_equality_checks
                        Text(
                          reward.toString(),
                          style: TextStyle(
                            fontSize: 17,
                            //fontWeight: FontWeight.bold,
                          ),
                        ),
                      ]),
                  TableRow(
                      decoration: BoxDecoration(color: Colors.white),
                      children: [
                        const Text(
                          "Punishment",
                          style: TextStyle(
                              fontSize: 17, fontWeight: FontWeight.bold),
                        ),
                        // ignore: unrelated_type_equality_checks
                        Text(
                          punishment.toString(),
                          style: TextStyle(
                            fontSize: 17,
                            //fontWeight: FontWeight.bold,
                          ),
                        ),
                      ]),
                ],
              ),
            )
          ],
        ));
  }
}
