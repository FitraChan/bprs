import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:bprs/screen/home.dart';
import 'package:bprs/screen/profil.dart';
import 'package:bprs/screen/riwayat.dart';
import 'package:bprs/screen/formCuti.dart';
import 'package:bprs/screen/daftarCuti.dart';
import 'package:bprs/screen/changePassword.dart';

import 'package:bprs/screen/login.dart';
import 'package:bprs/network_utils/api.dart';
//import 'package:bprs/screen/abse.dart';

// ignore: must_be_immutable
class Menu extends StatefulWidget {
  Menu({
    Key? key,
    required this.i,
  }) : super(key: key);

  int i;

  @override
  _MenuState createState() => _MenuState();
}

class _MenuState extends State<Menu> {
  //  FirebaseMessaging messaging;

  bool isAuth = false;
  String? name;
  String? noKaryawan;

  @override
  void initState() {
    _loadUserData();
    super.initState();
  }

  _loadUserData() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    var user = jsonDecode(localStorage.getString('user') ?? '');

    if (user != null) {
      setState(() {
        name = user['nama_lengkap'];
        noKaryawan = user['no_karyawan'];
      });
    } else {}
  }

  void _incrementTab(index) {
    setState(() {
      widget.i = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      Home(title: ""),
      DaftarCuti(),
      Profil(),

      FormCuti(),
      // Riwayat(),
    ];


    return Scaffold(
    
      drawer: Drawer(
        child: draw(),
      ),
      body: pages[widget.i],
      bottomNavigationBar: BottomNavigationBar( 
      
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
            backgroundColor: Colors.green,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Daftar Cuti',
            backgroundColor: Colors.green,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history_edu),
            label: 'Profil',
            backgroundColor: Colors.green,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.holiday_village),
            label: 'Form Cuti',
            backgroundColor: Colors.green,
          ),
        ],
        currentIndex: widget.i,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.amber[800],
        onTap: (index) {
          _incrementTab(index);
        },
      ),
    );
  }

  ListView draw() {
    return ListView(
      // Important: Remove any padding from the ListView.
      padding: EdgeInsets.zero,
      children: <Widget>[
        DrawerHeader(
          child: ListTile(
            title: Text(name ?? ""),
            leading: Icon(Icons.person_pin_circle_outlined),
            subtitle: Text(noKaryawan ?? ""),
            onTap: () {
              // Update the state of the app
              // ...
              // Then close the drawer
              Navigator.pop(context);
            },
          ),
          decoration: BoxDecoration(
            color: Color.fromARGB(143, 143, 136, 136),
          ),
        ),
        ListTile(
          title: Text('Ganti Password'),
          leading: const Icon(Icons.password_rounded),
          onTap: () {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (BuildContext context) => ChangePassword()));
          },
        ),
        ListTile(
          title: Text('Logout!'),
          leading: Icon(Icons.logout_rounded),
          onTap: () {
            // Update the state of the app
            // ...
            // Then close the drawer
            logout();
          },
        ),
      ],
    );
  }

  void logout() async {
    //final String _url_out = 'http://192.168.5.10/bprs_api/public/api/logout';

    String _url_out = 'https://absensi.mbcconsulting.id/api/logout';

    //var res = await http.post(Uri.parse(_url_out));

    var res = await Network().getData(_url_out);
    var body = json.decode(res.body);
    if (body['success']) {
      SharedPreferences localStorage = await SharedPreferences.getInstance();
      localStorage.remove('user');
      localStorage.remove('token');
      Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
    }
  }
}
