import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:maps_toolkit/maps_toolkit.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:bprs/network_utils/api.dart';
import 'dart:async';

import 'package:intl/intl.dart';
import 'package:bprs/screen/login.dart';
import 'package:bprs/screen/menu.dart';
import 'package:bprs/screen/riwayat.dart';
import 'package:bprs/screen/faceRecognition.dart';

import 'package:image_picker/image_picker.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
//import 'package:geolocator/geolocator.dart';
//import 'package:geocoding/geocoding.dart';
//import 'package:maps_toolkit/maps_toolkit.dart';

// class MessagingTutorial extends StatelessWidget {
//   const MessagingTutorial({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       title: 'Firebase Messaging',
//       theme: ThemeData(
//         primarySwatch: Colors.yellow,
//       ),
//       home: const Home(title: 'Firebase Messaging'),
//     );
//   }
// }

class Home extends StatefulWidget {
  const Home({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  // WidgetsFlutterBinding.ensureInitialized();

  // Obtain a list of the available cameras on the device.

  // final _baseUrl = 'http://192.168.5.10/bprs_api/public/api/show_paginate_post';
  final _baseUrl = 'https://absensi.mbcconsulting.id/api/show_paginate_post';
  int _page = 0;
  int _limit = 8;
  // There is next page or not
  bool _hasNextPage = true;
  // Used to display loading indicators when _firstLoad function is running
  bool _isFirstLoadRunning = false;
  // Used to display loading indicators when _loadMore function is running
  bool _isLoadMoreRunning = false;

  String? name;
  ScrollController _scrollController = new ScrollController();
  Position? _currentPosition;
  String? _currentAddress;
  bool isLoading = false;
  bool loadingLocation = false;

  bool loadingSave = false;
  String? base64Image;
  File? imageFile = null;
  String status = '';
  String errMessage = 'Error Uploading Image';

  List names = [];

// The controller for the ListView
  late ScrollController _controller;
  @override
  void initState() {
    _firstLoad();
    // fetchLokasi();
    _controller = new ScrollController()..addListener(_loadMore);
    _loadUserData();

    super.initState();
  }

  @override
  void dispose() {
    _controller.removeListener(_loadMore);
    super.dispose();
  }

  _loadUserData() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    var user = jsonDecode(localStorage.getString('user') ?? '');

    if (user != null) {
      setState(() {
        name = user['nama_lengkap'];
        // nim = user['str_user_name'];
      });
    } else {
      Login();
    }
  }

  Future _getCurrentLocation() async {
    bool isLocationServiceEnabled = await Geolocator.isLocationServiceEnabled();

    setState(() {
      loadingLocation = true;
    });

    await Geolocator.checkPermission();
    await Geolocator.requestPermission();

    Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best)
        .then((Position position) {
      setState(() {
        _currentPosition = position;
      });

      _getAddressFromLatLng();
    }).catchError((e) {
      upload();
      print("error....................................");
    });
  }

  var lat;
  var lang;

  void fetchLokasi() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    var user = jsonDecode(localStorage.getString('user') ?? '');
    Map data = {
      'karyawan_id': user['id'],
    };
    // String _url = 'http://192.168.5.10/bprs_api/public/api/profil';
    String _url = 'https://absensi.mbcconsulting.id/api/profilPerusahaan';
    final response = await Network().getData_post(data, _url);

    var c = json.decode(response.body);

    if (response.statusCode == 200) {
      //print(c['pend']);
      // print(latlang);

      setState(() {
        lat = c['lat'];
        lang = c['lang'];
      });
    } else {
      throw Exception('Failed to load album');
    }
  }

  bool jarak = false;

  String jauh = "";

  var jarakDoub;
  var longitude;
  var latitude;

  _getAddressFromLatLng() async {
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(
          _currentPosition!.latitude, _currentPosition!.longitude);

      Placemark place = placemarks[0];
      var latDouble = double.parse(lat);
      var langDouble = double.parse(lang);
      // final bankFajar = LatLng(-8.7123089, 115.1860254);
      final bankFajar = LatLng(latDouble, langDouble);
      final lokasi =
          LatLng(_currentPosition!.latitude, _currentPosition!.longitude);

      final distance =
          SphericalUtil.computeDistanceBetween(bankFajar, lokasi) / 1000.0;

      jarakDoub = double.parse(distance.toStringAsFixed(2));

      setState(() {
        _currentAddress =
            "${place.locality}, ${place.postalCode}, ${place.country},jarak = $jarakDoub km";

        if (distance >= 0 && distance <= 1) {
          jarak = true;
          //button();
          jauh = "Anda Berada Di Areal Bank Fajar";
          longitude = _currentPosition!.longitude;
          latitude = _currentPosition!.latitude;
        } else if (distance <= 5) {
          jarak = true;
          //button();
          jauh = "Jarak Anda Dekat Dengan Bank Fajar";
          longitude = _currentPosition!.longitude;
          latitude = _currentPosition!.latitude;
        } else {
          jauh = " Terlalu Jauh Dari Bank Fajar";
          longitude = _currentPosition!.longitude;
          latitude = _currentPosition!.latitude;
        }

        loadingLocation = false;
      });
    } catch (e) {
      print(e);
    }
  }

  Container Lokasi() {
    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (_currentAddress != null) Text(_currentAddress!),
          Text(jauh),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    return WillPopScope(
        onWillPop: () async {
          //  Navigator.of(context).pop(false);
          if (Platform.isAndroid) {
            SystemNavigator.pop();
          } else if (Platform.isIOS) {
            exit(0);
          }
          return Future.value(true);
        },
        child: Scaffold(
          backgroundColor: Color.fromARGB(255, 247, 249, 250),
          body: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                logo(),
                absen(),

                //  Text(loadingLocation ? 'Checking Location' : simpanGambar()),
                if (loadingLocation == true)
                  Text(
                    "Checking Location.....",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),

                if (loadingLocation == false && imageFile != null)
                  simpanGambar(),

                tulisan(),
                Lokasi(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [absenMasuk(), absenPulang()],
                ),
                _isFirstLoadRunning
                    ? const Center(
                        child: CircularProgressIndicator(),
                      )
                    : _buildList(),
                if (_isLoadMoreRunning == true)
                  const Padding(
                    padding: EdgeInsets.only(top: 10, bottom: 40),
                    child: Center(
                      child: CircularProgressIndicator(),
                    ),
                  ),

                // When nothing else to load
              ]),
          //
        ));
  }

  setStatus(String message) {
    setState(() {
      status = message;
    });
  }

  Container simpanGambar() {
    return Container(
      margin: EdgeInsets.only(top: 10),
      child: ConstrainedBox(
        constraints:
            BoxConstraints.tightFor(width: double.infinity, height: 50),
        child: FloatingActionButton.extended(
          heroTag: "btn1",
          icon: Icon(Icons.save),
          backgroundColor: Colors.blue,
          foregroundColor: Colors.white,
          label: Text(loadingSave ? 'Mohon Menunggu....' : 'Simpan'),
          onPressed: () {
            startUpload();
          },
        ),
      ),
    );
  }

  startUpload() {
    setStatus('Uploading Image...');
    if (null == imageFile) {
      setStatus(errMessage);
      return;
    }

    setState(() {
      loadingSave = true;
    });

    upload();
  }

  upload() async {
    base64Image = base64Encode(imageFile!.readAsBytesSync());
    String fileName = imageFile!.path.split('/').last;

    SharedPreferences localStorage = await SharedPreferences.getInstance();
    var user = jsonDecode(localStorage.getString('user') ?? '');

    //nim = user['str_nim'];
    Map data = {
      'base': base64Image,
      "image": fileName,
      'karyawan_id': user['id'],
      'lat': latitude,
      'long': longitude,
      'jarak': jarakDoub,
    };

    final String _url;
    var response;

    // final now = TimeOfDay.now();
    // if (now.hour >= 7 && now.hour <= 12) {
    //_url = 'http://192.168.5.10/bprs_api/public/api/save_konfirmation';
    _url = 'https://absensi.mbcconsulting.id/api/save_konfirmation_pagi';
    response = await Network().getData_post(data, _url);
    // } else {
    //   //_url = 'http://192.168.5.10/bprs_api/public/api/save_konfirmation_pulang';
    //   _url = 'https://absensi.mbcconsulting.id/api/save_konfirmation_siang';
    //   response = await Network().getData_post(data, _url);
    // }
    //  print(response.body);
    if (response.statusCode == 200) {
      Alert(
        context: context,
        type: AlertType.success,
        title: _currentAddress ?? "",
        desc: "Selamat Data Has Saved",
        buttons: [
          DialogButton(
            child: const Text(
              "Ok",
              style: TextStyle(color: Colors.white, fontSize: 14),
            ),
            onPressed: () => Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (BuildContext context) => Menu(i: 0))),
          )
        ],
      ).show();
    } else {
      //throw Exception('Failed to load album');
      //  print(err);
      SharedPreferences localStorage = await SharedPreferences.getInstance();
      localStorage.remove('user');
      localStorage.remove('token');
      Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
    }
  }

  Container absen() {
    return Container(
        child: SafeArea(
      top: true,
      bottom: true,
      child: Align(
        alignment: Alignment.center,
        child: Column(
          children: <Widget>[
            Container(
              margin: const EdgeInsets.only(left: 14.0, right: 14),
              height: 200,
              //margin: EdgeInsets.only(top: 20),
              child: imageFile != null
                  ? Image.file(File(imageFile!.path), height: 80)
                  : header(),
            ),
          ],
        ),
      ),
    ));
  }

  Container absenMasuk() {
    final border = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10.0),
    );

    return Container(
      // color: Colors.red,
      margin: const EdgeInsets.only(left: 14.0, right: 14, top: 10),
      width: 155,
      height: 80,
      child: Card(
          color: Colors.red,
          shape: border,
          child: Column(
            //mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.only(top: 14, left: 14.0),
                child: Text(
                  "Absen Masuk",
                  style: TextStyle(
                      //  fontWeight: FontWeight.bold,
                      color: Colors.white,
                      fontSize: 14),
                ),
              ),
              Container(
                padding: const EdgeInsets.only(left: 14.0, top: 10),
                child: Text(
                  cekAbsenMasuk.toString(),
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      fontSize: 16),
                ),
              ),
            ],
          )),
    );
  }

  Container absenPulang() {
    final border = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10.0),
    );

    return Container(
      // color: Colors.red,
      margin: const EdgeInsets.only(top: 10, right: 14),
      width: 155,
      height: 80,
      child: Card(
          color: Color.fromARGB(255, 65, 63, 63),
          shape: border,
          child: Column(
            //mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.only(top: 14, left: 14.0),
                child: Text(
                  "Absen Pulang",
                  style: TextStyle(
                      //  fontWeight: FontWeight.bold,
                      color: Colors.white,
                      fontSize: 14),
                ),
              ),
              Container(
                padding: const EdgeInsets.only(left: 14.0, top: 10),
                child: Text(
                  cekAbsenPulang.toString(),
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      fontSize: 16),
                ),
              ),
            ],
          )),
    );
  }

  final picker = ImagePicker();

  Future imageSelector() async {
    final pickedFile = await picker.pickImage(
        source: ImageSource.camera, maxHeight: 1024, maxWidth: 1024);

    _getCurrentLocation();

    setState(() {
      if (pickedFile != null) {
        imageFile = File(pickedFile.path);
      } else {
        print('No image selected.');
      }
    });
  }

  var firstCamera;

  Container showKamera() {
    return Container(
      margin: const EdgeInsets.only(top: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        // color: Colors.white,

        image: const DecorationImage(
          image: AssetImage('images/icon_camera_red.png'),
          fit: BoxFit.fill,
        ),
      ),
      height: 50,
      width: 50,
      child: GestureDetector(
        onTap: () {
          imageSelector();
          // Navigator.push(
          //   context,
          //   MaterialPageRoute(
          //       builder: (context) => FaceRecognitionView(
          //             name: name.toString(),
          //           )),
          // );

          //imageSelector();
        },
      ),
    );
  }

  Container NotShowKamera() {
    return Container(
      margin: const EdgeInsets.only(top: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        // color: Colors.white,

        image: const DecorationImage(
          image: AssetImage('images/no_camera.png'),
          fit: BoxFit.fill,
        ),
      ),
      height: 50,
      width: 50,
    );
  }

  Container header() {
    final border = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10.0),
    );

    var absensi;

    var kamera;
    if (jam_masuk != "" && jam_pulang == "") {
      absensi = "Absen Pulang";

      kamera = showKamera();
    } else if (cekSatpamAbsenKemarin == 'true' &&
        cekSatpamTidakAbsen == 'false') {
      absensi = "Absen Pulang";
      kamera = showKamera();
    } else if (cekSatpamAbsenKemarin == 'false' &&
        cekSatpamTidakAbsen == 'true') {
      absensi = "Absen Masuk";
    } else if (jam_masuk != "" && jam_pulang != "") {
      kamera = showKamera();
      absensi = "Absen Masuk";
      kamera = NotShowKamera();
    } else {
      absensi = "Absen Masuk";
      kamera = showKamera();
    }
    return Container(
      width: double.infinity,
      height: 220,
      margin: const EdgeInsets.only(left: 14.0, right: 14),
      child: Card(
        shape: border,
        color: Colors.white,
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                padding: const EdgeInsets.only(left: 14.0, top: 12.0),
                child: const Text(
                  "Selamat Datang",
                  style: TextStyle(fontSize: 13),
                ),
              ),
              Container(
                padding: const EdgeInsets.only(left: 14.0),
                child: Text(
                  name ?? "",
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                    // decoration: TextDecoration.underline,
                  ),
                ),
              ),
              Container(
                child: Divider(
                  color: Colors.black26,
                  indent: 11,
                  endIndent: 11,
                ),
              ),
              Container(
                  child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Column(
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            // ignore: unnecessary_new
                            new MaterialPageRoute(
                                builder: (context) => Menu(
                                      i: 2,
                                    )),
                          );
                        },
                        child: Container(
                            margin: const EdgeInsets.only(top: 5),
                            height: 60,
                            width: 60,
                            child: foto != ""
                                ? Container(
                                    width: 60,
                                    height: 60,
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        image: DecorationImage(
                                            fit: BoxFit.fill,
                                            image: NetworkImage(foto ?? ""))),
                                    margin: const EdgeInsets.only(top: 10.0),
                                  )
                                : const Text(
                                    'no Image',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 14),
                                    textAlign: TextAlign.center,
                                  )),
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 7),
                        child: const Text(
                          "Profile",
                          style: TextStyle(fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                  Column(
                    children: [
                      kamera,
                      Container(
                        margin: const EdgeInsets.only(top: 7),
                        child: Text(
                          absensi,
                          style: TextStyle(fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                  Column(
                    children: [
                      Container(
                        margin: const EdgeInsets.only(top: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          // color: Colors.white,

                          image: const DecorationImage(
                            image: AssetImage('images/icon_riwayat_bprs.png'),
                            fit: BoxFit.fill,
                          ),
                        ),
                        height: 50,
                        width: 50,
                        child: GestureDetector(
                          // artinya direct ke halaman menu dulu trus baru di arahkan ke halaman yg di maksud berdasarkan index yg ada di widget menu
                          // paham cong.. kalau ga banyak dzikir....
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => Riwayat()),
                            );
                          },
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 7),
                        child: const Text(
                          "Riwayat",
                          style: TextStyle(fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ],
              ))
            ]),
      ),
    );
  }

  Container tulisan() {
    return Container(
      margin: const EdgeInsets.only(top: 7),
      child: const Text(
        "Data Absensi",
        style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
      ),
    );
  }

  Container logo() {
    return Container(
      margin: const EdgeInsets.only(top: 25),
      width: 130,
      height: 100,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        // color: Colors.white,

        image: const DecorationImage(
          image: AssetImage('images/logo_bank.png'),
          fit: BoxFit.fill,
        ),
      ),
    );
  }

  Expanded _buildList() {
    final border = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10.0),
    );

    return Expanded(
      child: ListView.builder(
          itemCount: _posts.length,
          controller: _controller,
          itemBuilder: (BuildContext context, int index) {
            var inputFormat = DateFormat('yyyy-MM-dd');
            var inputDate =
                inputFormat.parse(_posts[index]['tanggal']!.toString());
            var outputFormat = DateFormat('dd/MM/yyyy');
            var outputDate = outputFormat.format(inputDate);

            //var
            var jamFormat = DateFormat('yyyy-MM-dd HH:mm:ss');
            var inputJamMasuk =
                jamFormat.parse(_posts[index]['jam_masuk']!.toString());

            var outputJamFormat = DateFormat('HH:mm:ss');
            var outputJamMasuk = outputJamFormat.format(inputJamMasuk);

            // var inputJamPulang =
            //     jamFormat.parse(_posts[index]['jam_pulang']);
            final border = RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            );

            //  var outputJamPulang = outputJamFormat.format(inputJamPulang);
            return Container(
                margin: const EdgeInsets.only(left: 14.0, right: 14),
                height: 170,
                width: double.infinity,
                child: Card(
                  shape: border,
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Container(
                        padding: const EdgeInsets.only(left: 20, right: 20),
                        child: Table(
                          // defaultVerticalAlignment:
                          //     TableCellVerticalAlignment.middle,
                          columnWidths: const {
                            0: FlexColumnWidth(2),
                            1: FlexColumnWidth(4),
                          },
                          //textDirection: TextDirection.ltr,
                          border: TableBorder.symmetric(
                              inside: BorderSide(
                                  width: 1, color: Colors.grey.shade300),
                              outside: BorderSide(
                                  width: 1, color: Colors.grey.shade300)),
                          defaultColumnWidth: const FixedColumnWidth(150),
                          defaultVerticalAlignment:
                              TableCellVerticalAlignment.middle,

                          children: [
                            TableRow(
                                decoration:
                                    BoxDecoration(color: Colors.grey[200]),
                                children: [
                                  Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: const [
                                        Text(
                                          'Tanggal',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ]),
                                  Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(outputDate != Null
                                            ? outputDate
                                            : "Null"),
                                      ]),
                                ]),
                            TableRow(children: [
                              const Text(
                                "Jam Masuk",
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              Text(outputJamMasuk),
                            ]),
                            TableRow(
                                decoration:
                                    BoxDecoration(color: Colors.grey[200]),
                                children: [
                                  const Text(
                                    "Jam Pulang",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  // ignore: unrelated_type_equality_checks
                                  Text(_posts[index]['jam_pulang'].toString()),
                                ]),
                            TableRow(
                                decoration:
                                    BoxDecoration(color: Colors.grey[200]),
                                children: [
                                  const Text(
                                    "Status",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  Text(_posts[index]['keterangan'].toString()),
                                ]),
                          ],
                        ),
                      ),
                    ],
                  ),
                ));
          }),
    );
  }

  List _posts = [];
  var jam_masuk;
  var jam_pulang;
  var cekSatpamAbsenKemarin;
  String? cekAbsenMasuk;
  String? cekAbsenPulang;
  String? foto;

  var cekSatpamTidakAbsen;
  void _firstLoad() async {
    setState(() {
      _isFirstLoadRunning = true;
    });

    try {
      SharedPreferences localStorage = await SharedPreferences.getInstance();
      var user = jsonDecode(localStorage.getString('user') ?? '');
      Map data = {
        'karyawan_id': user['id'],
        'page': _page,
        'limit': _limit,
      };
      final res = await Network().getData_post(data, _baseUrl);

      var a = json.decode(res.body);

      setState(() {
        var data = a['absen'];
        jam_masuk = a['jam_masuk'];
        jam_pulang = a['jam_pulang'];
        cekSatpamTidakAbsen = a['cek_satpam_tidak_absen'];
        cekSatpamAbsenKemarin = a['cek_satpam_absen_kemarin'];
        cekAbsenMasuk = a['absen_masuk'];
        cekAbsenPulang = a['absen_pulang'];
        foto = a['foto'];
        _posts = data['data'];
      });
    } catch (err) {
      print(err);
      SharedPreferences localStorage = await SharedPreferences.getInstance();
      localStorage.remove('user');
      localStorage.remove('token');
      Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
    }

    setState(() {
      _isFirstLoadRunning = false;
    });
  }

  // This function will be triggered whenver the user scroll
  // to near the bottom of the list view
  void _loadMore() async {
    if (_hasNextPage == true &&
        _isFirstLoadRunning == false &&
        _isLoadMoreRunning == false &&
        _controller.position.extentAfter < 300) {
      setState(() {
        _isLoadMoreRunning = true; // Display a progress indicator at the bottom
      });

      if (_page == 0) {
        _page += 1;
      }
      _page += 1; // Increase _page by 1

      try {
        SharedPreferences localStorage = await SharedPreferences.getInstance();
        var user = jsonDecode(localStorage.getString('user') ?? '');
        Map data = {
          'karyawan_id': user['id'],
          'page': _page,
          'limit': _limit,
        };
        final res = await Network().getData_post(data, _baseUrl);

        var c = json.decode(res.body);
        final List fetchedPosts = c['data'];

        //  print(fetchedPosts.length);
        if (fetchedPosts.length > 0) {
          setState(() {
            //  _posts.clear();
            _posts.addAll(fetchedPosts);
          });
        } else {
          // This means there is no more data
          // and therefore, we will not send another GET request
          setState(() {
            _hasNextPage = false;
          });
        }
      } catch (err) {
        print('Something went wrong!');
      }

      setState(() {
        _isLoadMoreRunning = false;
      });
    }
  }
}
