import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:bprs/network_utils/api.dart';
import 'package:bprs/screen/menu.dart';
import 'package:bprs/screen/login.dart';
import 'package:bprs/model/karyawanModel.dart';
import 'package:bprs/model/absensiModel.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';

class Riwayat extends StatefulWidget {
  Riwayat({
    Key? key,
  }) : super(key: key);

  @override
  _RiwayatState createState() => _RiwayatState();
}

class _RiwayatState extends State<Riwayat> {
  //  FirebaseMessaging messaging;

  String? name;
  String? _dropdownError;
  bool isLoading = false;
  String? notificationText;
  String? base64Image;
  File? imageFile = null;
  String status = '';
  String errMessage = 'Error Uploading Image';
  bool loadingSave = false;
  String? idDepartement;
  String? jabatan;
  TextEditingController tanggalAwal = TextEditingController();
  TextEditingController tanggalAkhir = TextEditingController();
  List dataDept = [];
  List names = [];
  List dataJab = [];

  List filteredNames = [];

  @override
  void initState() {
    // _loadUserData();

    //getJabatan();
    //  fetchAlbum();
    super.initState();
  }

  void _getMoreData() async {
    if (!isLoading) {
      setState(() {
        isLoading = true;
      });
      SharedPreferences localStorage = await SharedPreferences.getInstance();
      var user = jsonDecode(localStorage.getString('user') ?? '');
      Map data = {
        'karyawan_id': user['id'],
        'tanggal_awal': tanggalAwal.text,
        'tanggal_akhir': tanggalAkhir.text,
      };

      // final String _url = 'http://192.168.5.10/bprs_api/public/api/cari_absen';
      final String _url = 'https://absensi.mbcconsulting.id/api/cari_absen';
      final response = await Network().getData_post(data, _url);

      // print(response.body);
      List tempList = [];
      // ignore: deprecated_member_use
      List<dynamic> values = <dynamic>[];
      values = json.decode(response.body);
      for (int i = 0; i < values.length; i++) {
        tempList.add(values[i]);
      }

      setState(() {
        names.clear();
        isLoading = false;
        names.addAll(tempList);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => Menu(
                      i: 0,
                    )),
          );
          return Future.value(true);
        },
        child: Scaffold(
          backgroundColor: const Color.fromARGB(255, 247, 249, 250),
          body: SingleChildScrollView(
            child: Column(children: <Widget>[
              logo(),
              cari(),
              tulisan(),
              dataRiwayat(),
            ]),
          ),
        ));
  }

  Container logo() {
    return Container(
      margin: const EdgeInsets.only(top: 25),
      width: 130,
      height: 40,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        // color: Colors.white,

        image: const DecorationImage(
          image: AssetImage('images/logo_bprs.jpg'),
          fit: BoxFit.fill,
        ),
      ),
    );
  }

  Container tulisan() {
    return Container(
      margin: const EdgeInsets.only(top: 10, left: 14.0, right: 14),
      child: Text(
        'Data Absensi',
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
      ),
    );
  }

  Container cari() {
    final border = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10.0),
    );
    final format = DateFormat("dd-MM-yyyy");
    return Container(
      margin: const EdgeInsets.only(top: 25, left: 14.0, right: 14),
      height: 250,
      child: Card(
        shape: border,
        color: Colors.white,
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              Container(
                margin: const EdgeInsets.only(top: 10.0, left: 10, right: 10),
                child: DateTimeField(
                  validator: (value) {
                    if (value == null) {
                      return 'Please enter a date';
                    }
                    return null;
                  },
                  decoration: const InputDecoration(
                    hintText: "Tanggal Awal",
                    labelText: "Tanggal Awal",
                    // prefixText: _currency,
                    prefixIcon: Icon(
                      Icons.date_range,
                      color: Colors.grey,
                    ),
                  ),
                  format: format,
                  controller: tanggalAwal,
                  onShowPicker: (context, currentValue) {
                    return showDatePicker(
                        context: context,
                        firstDate: DateTime(1900),
                        initialDate: currentValue ?? DateTime.now(),
                        lastDate: DateTime(2100));
                  },
                ),
              ),
              Container(
                margin: const EdgeInsets.only(top: 10.0, left: 10, right: 10),
                child: DateTimeField(
                  validator: (value) {
                    if (value == null) {
                      return 'Please enter a date';
                    }
                    return null;
                  },
                  decoration: new InputDecoration(
                    hintText: "Tanggal Akhir",
                    labelText: "Tanggal Akhir",
                    // prefixText: _currency,
                    prefixIcon: Icon(
                      Icons.date_range,
                      color: Colors.grey,
                    ),
                  ),
                  format: format,
                  controller: tanggalAkhir,
                  onShowPicker: (context, currentValue) {
                    return showDatePicker(
                        context: context,
                        firstDate: DateTime(1900),
                        initialDate: currentValue ?? DateTime.now(),
                        lastDate: DateTime(2100));
                  },
                ),
              ),
              Container(
                margin: const EdgeInsets.only(top: 10.0, left: 10, right: 10),
                child: ConstrainedBox(
                  constraints: BoxConstraints.tightFor(width: 200, height: 50),
                  child: FloatingActionButton.extended(
                    backgroundColor: Colors.tealAccent[700],
                    foregroundColor: Colors.white,
                    icon: Icon(Icons.search_sharp),
                    onPressed: () {
                      _getMoreData();
                    },
                    label: Text(isLoading ? 'Mohon Menunggu....' : 'Cari'),
                    // child: ,
                  ),
                ),
              ),
              SizedBox(
                height: 10,
              )
            ]),
      ),
    );
  }

  Container dataRiwayat() {
    return Container(
      child: ListView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: names.length,
        itemBuilder: (BuildContext context, int index) {
          var inputFormat = DateFormat('yyyy-MM-dd');
          var inputDate =
              inputFormat.parse(names[index]['tanggal']!.toString());
          var outputFormat = DateFormat('dd/MM/yyyy');
          var outputDate = outputFormat.format(inputDate);

          //var
          var jamFormat = DateFormat('yyyy-MM-dd HH:mm:ss');
          var inputJamMasuk =
              jamFormat.parse(names[index]['jam_masuk']!.toString());

          var outputJamFormat = DateFormat('HH:mm:ss');
          var outputJamMasuk = outputJamFormat.format(inputJamMasuk);
          var outputJamPulang;
          if (names[index]['jam_pulang']!.toString() == "Belum Absen Pulang") {
            outputJamPulang = "Belum Absen Pulang";
          } else {
            var inputJamPulang =
                jamFormat.parse(names[index]['jam_pulang']!.toString());

            outputJamPulang = outputJamFormat.format(inputJamPulang);
          }

          final border = RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          );

          return Container(
              margin: const EdgeInsets.only(top: 10, left: 14.0, right: 14),
              height: 170,
              child: Card(
                shape: border,
                color: Colors.white,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.only(left: 20, right: 20),
                      child: Table(
                        // defaultVerticalAlignment:
                        //     TableCellVerticalAlignment.middle,
                        columnWidths: const {
                          0: FlexColumnWidth(2),
                          1: FlexColumnWidth(4),
                        },
                        //textDirection: TextDirection.ltr,
                        border: TableBorder.symmetric(
                            inside: BorderSide(
                                width: 1, color: Colors.grey.shade300),
                            outside: BorderSide(
                                width: 1, color: Colors.grey.shade300)),
                        defaultColumnWidth: const FixedColumnWidth(150),
                        defaultVerticalAlignment:
                            TableCellVerticalAlignment.middle,

                        children: [
                          TableRow(
                              decoration:
                                  BoxDecoration(color: Colors.grey[200]),
                              children: [
                                Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: const [
                                      Text(
                                        'Tanggal',
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ]),
                                Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(outputDate != Null
                                          ? outputDate
                                          : "Null"),
                                    ]),
                              ]),
                          TableRow(children: [
                            const Text(
                              "Jam Masuk",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            Text(outputJamMasuk),
                          ]),
                          TableRow(
                              decoration:
                                  BoxDecoration(color: Colors.grey[200]),
                              children: [
                                const Text(
                                  "Jam Pulang",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                // ignore: unrelated_type_equality_checks
                                Text(outputJamPulang),
                              ]),
                          TableRow(
                              decoration:
                                  BoxDecoration(color: Colors.grey[200]),
                              children: [
                                const Text(
                                  "Status",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                Text(names[index]['keterangan'].toString()),
                              ]),
                        ],
                      ),
                    ),
                  ],
                ),
              ));
          //  }
        },
      ),
    );
  }
}
