// ignore_for_file: deprecated_member_use

import 'dart:convert';
import 'dart:io';
import 'package:bprs/theme.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:bprs/network_utils/api.dart';
import 'package:bprs/screen/menu.dart';
import 'package:bprs/screen/login.dart';
import 'package:bprs/screen/daftarCuti.dart';
import 'package:flutter/services.dart';

import 'package:bprs/model/karyawanModel.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
//import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';

class ChangePassword extends StatefulWidget {
  ChangePassword({
    Key? key,
  }) : super(key: key);

  @override
  _ChangePasswordState createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {
  bool loadingSave = false;

  TextEditingController? email = TextEditingController();
  TextEditingController? password = TextEditingController();

  @override
  void initState() {
    fetchAlbum();
    super.initState();
  }

  void fetchAlbum() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    var user = jsonDecode(localStorage.getString('user') ?? '');
    Map data = {
      'karyawan_id': user['id'],
    };
    //  String _url = 'http://192.168.5.10/bprs_api/public/api/profil';
    String _url = 'https://absensi.mbcconsulting.id/api/profil';
    final response = await Network().getData_post(data, _url);
    //  print(response.body);
    var c = json.decode(response.body);
    if (response.statusCode == 200) {
      // var b = json.decode(response.body);
      var b = c['absen'];
      setState(() {
        email = TextEditingController(text: b['email']);
        password = TextEditingController(text: b['password']);
      });
    } else {
      throw Exception('Failed to load album');
    }
  }

  startUpload() {
    setState(() {
      loadingSave = true;
    });

    upload();
  }

  upload() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    var user = jsonDecode(localStorage.getString('user') ?? '');

    //nim = user['str_nim'];
    Map data = {
      // 'no_karyawan': noKaryawan?.text,
      'email': email?.text,
      'password': password?.text,
      'karyawan_id': user['id'],
    };

    //final String _url = 'http://192.168.5.10/bprs_api/public/api/save_cuti';
    final String _url = 'https://absensi.mbcconsulting.id/api/save_karyawan';

    var response = await Network().getData_post(data, _url);
    if (response.statusCode == 200) {
      Alert(
        context: context,
        type: AlertType.success,
        title: "berhasil",
        desc: "Selamat Data Has Saved",
        buttons: [
          DialogButton(
            child: const Text(
              "Ok",
              style: TextStyle(color: Colors.white, fontSize: 14),
            ),
            onPressed: () => Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (BuildContext context) => Menu(i: 0))),
          )
        ],
      ).show();
    } else {
      throw Exception('Failed to load album');
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => Menu(
                      i: 0,
                    )),
          );
          return Future.value(true);
        },
        child: Scaffold(
          backgroundColor: Colors.grey[200],
          body: SingleChildScrollView(
            child: Column(children: <Widget>[
              dataProfil(),
            ]),
          ),
        ));
  }

  Container simpan() {
    return Container(
      child: ConstrainedBox(
        constraints: BoxConstraints.tightFor(width: 200, height: 45),
        child: FloatingActionButton.extended(
          icon: const Icon(Icons.save),

          backgroundColor: Colors.tealAccent[700],
          foregroundColor: Colors.white,
          onPressed: () {
            var validate = _form.currentState!.validate();
            if (validate == false) {
              return;
            }
            startUpload();
          },
          label: Text(loadingSave ? 'Mohon Menunggu....' : 'Simpan'),
          //child: Text(loadingSave ? 'Mohon Menunggu....' : 'Simpan'),
        ),
      ),
    );
  }

  final GlobalKey<FormState> _form = GlobalKey<FormState>();
  final TextEditingController _confirmPass = TextEditingController();

  Container dataProfil() {
    final border = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10.0),
    );

    bool passwordVisible = false;
    void togglePassword() {
      setState(() {
        passwordVisible = !passwordVisible;
      });
    }

    return Container(
        width: double.infinity,
        margin: const EdgeInsets.only(top: 18.0, left: 14.0, right: 14),
        child: Form(
          key: _form,
          child: Card(
            shape: border,
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 10.0, left: 10.0),
                  child: const Text(
                    "Email",
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.only(top: 10.0, left: 10, right: 10),
                  child: TextFormField(
                    style: const TextStyle(color: Color(0xFF000000)),
                    cursorColor: const Color(0xFF9b9b9b),
                    keyboardType: TextInputType.text,
                    //obscureText: true,

                    controller: email,
                    decoration: InputDecoration(
                      fillColor: Colors.white,
                      hintText: "Email",
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(5.0),
                        borderSide: const BorderSide(
                          color: Colors.grey,
                          width: 2.0,
                        ),
                      ),
                    ),
                  ),
                ),

                Container(
                  margin: const EdgeInsets.only(top: 10.0, left: 10.0),
                  child: const Text(
                    "Password",
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                Container(
                  margin: const EdgeInsets.only(top: 10.0, left: 10, right: 10),
                  child: TextFormField(
                    obscureText: !passwordVisible,
                    style: const TextStyle(color: Color(0xFF000000)),
                    cursorColor: const Color(0xFF9b9b9b),
                    keyboardType: TextInputType.text,
                    controller: password,
                    decoration: InputDecoration(
                      fillColor: Color.fromRGBO(255, 255, 255, 1),
                      hintText: "Password",
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(5.0),
                        borderSide: const BorderSide(
                          color: Colors.grey,
                          width: 2.0,
                        ),
                      ),
                    ),
                  ),
                ),

                Container(
                  margin: const EdgeInsets.only(top: 10.0, left: 10.0),
                  child: const Text(
                    "Confirm Password",
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                Container(
                  margin: const EdgeInsets.only(top: 10.0, left: 10, right: 10),
                  child: TextFormField(
                    obscureText: !passwordVisible,
                    style: const TextStyle(color: Color(0xFF000000)),
                    cursorColor: const Color(0xFF9b9b9b),
                    keyboardType: TextInputType.text,
                    //obscureText: true,
                    //  readOnly: true,
                    controller: _confirmPass,
                    validator: (val) {
                      if (val!.isEmpty) return 'Empty';
                      if (val != password?.text) return 'Not Match';
                      return null;
                    },
                    decoration: InputDecoration(
                      hintStyle: heading6.copyWith(color: textGrey),
                      fillColor: Color.fromRGBO(255, 255, 255, 1),
                      hintText: "Confirm Password",
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(5.0),
                        borderSide: const BorderSide(
                          color: Colors.grey,
                          width: 2.0,
                        ),
                      ),
                    ),
                  ),
                ),

                Container(
                  margin: const EdgeInsets.only(top: 10.0, left: 10),
                  child: simpan(),
                ),
                SizedBox(height: 10),
                //simpan(),
              ],
            ),
          ),
        ));
  }
}
