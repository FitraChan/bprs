// ignore_for_file: deprecated_member_use

import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:bprs/network_utils/api.dart';
import 'package:bprs/screen/menu.dart';
import 'package:bprs/screen/login.dart';
import 'package:bprs/screen/daftarCuti.dart';
import 'package:flutter/services.dart';

import 'package:bprs/model/karyawanModel.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';

class FormCuti extends StatefulWidget {
  FormCuti({
    Key? key,
  }) : super(key: key);

  @override
  _FormCutiState createState() => _FormCutiState();
}

class _FormCutiState extends State<FormCuti> {
  //  FirebaseMessaging messaging;
  //String? selectDept;
  String? name;
  String? _dropdownError;
  //String? noKaryawan;
  String? notificationText;
  String? base64Image;
  File? imageFile = null;
  String status = '';
  String? cutiValue = 'Sakit';
  String errMessage = 'Error Uploading Image';
  bool loadingSave = false;
  String? idDepartement;
  String? jabatan;
  TextEditingController? namaKaryawan = TextEditingController();
  TextEditingController? nik = TextEditingController();
  TextEditingController? noHp = TextEditingController();
  TextEditingController? cuti = TextEditingController();
  TextEditingController? keperluan = TextEditingController();
  TextEditingController tanggalAwal = TextEditingController();
  TextEditingController tanggalAkhir = TextEditingController();
  TextEditingController? email = TextEditingController();
  TextEditingController? password = TextEditingController();
  TextEditingController? durasi = TextEditingController();

  List dataDept = [];
  List names = [];
  List dataJab = [];

  List filteredNames = [];

  @override
  void initState() {
    // _loadUserData();
    getSWData2();
    getJabatan();
    fetchAlbum();
    super.initState();
  }

  void fetchAlbum() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    var user = jsonDecode(localStorage.getString('user') ?? '');
    Map data = {
      'karyawan_id': user['id'],
    };
    //  String _url = 'http://192.168.5.10/bprs_api/public/api/profil';
    String _url = 'https://absensi.mbcconsulting.id/api/profil';
    final response = await Network().getData_post(data, _url);
    //  print(response.body);
    var c = json.decode(response.body);
    if (response.statusCode == 200) {
      // var b = json.decode(response.body);
      var b = c['absen'];
      setState(() {
        namaKaryawan = TextEditingController(text: b['nama_lengkap']);
        nik = TextEditingController(text: b['nik']);
        idDepartement = b['departement_id'].toString();
        email = TextEditingController(text: b['email']);
        noHp = TextEditingController(text: b['no_telp']);
      });
    } else {
      throw Exception('Failed to load album');
    }
  }

  final picker = ImagePicker();

  Future getImage(ImageSource media) async {
    final img =
        await picker.pickImage(source: media, maxHeight: 1024, maxWidth: 1024);
    setState(() {
      imageFile = File(img!.path);
    });
  }

  void myAlertImage() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            title: const Text('Please choose media to select'),
            content: Container(
              height: MediaQuery.of(context).size.height / 6,
              child: Column(
                children: <Widget>[
                  FloatingActionButton.extended(
                    onPressed: () {
                      Navigator.pop(context);
                      getImage(ImageSource.gallery);
                    },
                    icon: const Icon(Icons.image),
                    label: Text("From Gallery"),
                  ),
                  FloatingActionButton.extended(
                    onPressed: () {
                      Navigator.pop(context);
                      getImage(ImageSource.camera);
                    },
                    icon: const Icon(Icons.camera),
                    label: Text("From Camera"),
                  ),
                ],
              ),
            ),
          );
        });
  }

  setStatus(String message) {
    setState(() {
      status = message;
    });
  }

  startUpload() {
    setStatus('Uploading Image...');

    setState(() {
      loadingSave = true;
    });
    if (null == imageFile) {
      uploadWithoutImage();
      return;
    }

    upload();
  }

  upload() async {
    base64Image = base64Encode(imageFile!.readAsBytesSync());
    String fileName = imageFile!.path.split('/').last;

    SharedPreferences localStorage = await SharedPreferences.getInstance();
    var user = jsonDecode(localStorage.getString('user') ?? '');

    //nim = user['str_nim'];
    Map data = {
      // 'no_karyawan': noKaryawan?.text,
      'tanggal_mulai': tanggalAwal.text,
      'tanggal_selesai': tanggalAkhir.text,
      'keterangan': keperluan?.text,
      'jenis_absen': cutiValue,
      'base': base64Image,
      'durasi': durasi?.text,
      "image": fileName,
      'karyawan_id': user['id'],
    };

    //final String _url = 'http://192.168.5.10/bprs_api/public/api/save_cuti';
    final String _url = 'https://absensi.mbcconsulting.id/api/save_cuti';

    var response = await Network().getData_post(data, _url);

    print(response.body);

    if (response.statusCode == 200) {
      Alert(
        context: context,
        type: AlertType.success,
        title: "berhasil",
        desc: "Selamat Data Has Saved",
        buttons: [
          DialogButton(
            child: const Text(
              "Ok",
              style: TextStyle(color: Colors.white, fontSize: 14),
            ),
            onPressed: () => Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (BuildContext context) => Menu(i: 0))),
          )
        ],
      ).show();
    } else {
      throw Exception('Failed to load album');
    }
  }

  uploadWithoutImage() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    var user = jsonDecode(localStorage.getString('user') ?? '');

    //nim = user['str_nim'];
    Map data = {
      'nik': nik?.text,
      'tanggal_mulai': tanggalAwal.text,
      'tanggal_selesai': tanggalAkhir.text,
      'keterangan': keperluan?.text,
      'jenis_absen': cutiValue,
      'durasi': durasi?.text,
      'karyawan_id': user['id'],
    };

    //final String _url = 'http://192.168.5.10/bprs_api/public/api/save_cuti';
    final String _url = 'https://absensi.mbcconsulting.id/api/save_cuti';
    var response = await Network().getData_post(data, _url);

    if (response.statusCode == 200) {
      Alert(
        context: context,
        type: AlertType.success,
        title: "berhasil",
        desc: "Selamat Data Has Saved",
        buttons: [
          DialogButton(
            child: const Text(
              "Mantap",
              style: TextStyle(color: Colors.white, fontSize: 14),
            ),
            onPressed: () => Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (BuildContext context) => Menu(i: 0))),
          )
        ],
      ).show();
    } else {
      throw Exception('Failed to load album');
    }
  }

// print("fail");
  // If the server did not return a 200 OK response,
  // then throw an exception.
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => Menu(
                      i: 0,
                    )),
          );
          return Future.value(true);
        },
        child: Scaffold(
          backgroundColor: Colors.grey[200],
          body: SingleChildScrollView(
            child: Column(children: <Widget>[
              dataProfil(),
            ]),
          ),
        ));
  }

  Container simpan() {
    return Container(
      child: ConstrainedBox(
        constraints: BoxConstraints.tightFor(width: 200, height: 45),
        child: FloatingActionButton.extended(
          icon: const Icon(Icons.save),
          // style: ButtonStyle(
          //   backgroundColor: MaterialStateProperty.all(Colors.tealAccent[700]),
          // ),
          backgroundColor: Colors.tealAccent[700],
          foregroundColor: Colors.white,
          onPressed: () {
            startUpload();
          },
          label: Text(loadingSave ? 'Mohon Menunggu....' : 'Simpan'),
          //child: Text(loadingSave ? 'Mohon Menunggu....' : 'Simpan'),
        ),
      ),
    );
  }

  Future<String> getSWData2() async {
    //final String url = "http://192.168.5.10/bprs_api/public/api/departement";
    final String url = 'https://absensi.mbcconsulting.id/api/departement';

    final response = await Network().getData(url);
    var resBody = json.decode(response.body);

    // print(resBody);
    setState(() {
      dataDept = resBody;
    });

    return "Sucess";
  }

  Future<String> getJabatan() async {
    // final String url = "http://192.168.5.10/bprs_api/public/api/jabatan";
    final String url = 'https://absensi.mbcconsulting.id/api/jabatan';

    final response = await Network().getData(url);
    var resBody = json.decode(response.body);

    //print(resBody);
    setState(() {
      dataJab = resBody;
    });

    return "Sucess";
  }

  Container dataProfil() {
    final border = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10.0),
    );
    final format = DateFormat("dd-MM-yyyy");

    // if (idDepartement != null && selectDept == null) {
    //   selectDept = idDepartement;
    // }
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 18.0, left: 14.0, right: 14),
      child: Card(
        shape: border,
        color: Colors.white,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              margin: const EdgeInsets.only(top: 10.0, left: 10.0),
              child: const Text(
                "NIK Karyawan",
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 10.0, left: 10, right: 10),
              child: TextFormField(
                style: const TextStyle(color: Color(0xFF000000)),
                cursorColor: const Color(0xFF9b9b9b),
                keyboardType: TextInputType.text,
                //obscureText: true,
                readOnly: true,
                controller: nik,
                decoration: InputDecoration(
                  fillColor: Colors.white,
                  hintText: "Kode Karyawan",
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(5.0),
                    borderSide: const BorderSide(
                      color: Colors.grey,
                      width: 2.0,
                    ),
                  ),
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 10.0, left: 10.0),
              child: const Text(
                "Nama Karyawan",
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 10.0, left: 10, right: 10),
              child: TextFormField(
                style: const TextStyle(color: Color(0xFF000000)),
                cursorColor: const Color(0xFF9b9b9b),
                keyboardType: TextInputType.text,
                controller: namaKaryawan,
                readOnly: true,
                decoration: InputDecoration(
                  fillColor: Colors.white,
                  hintText: "Nama Karyawan",
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(5.0),
                    borderSide: const BorderSide(
                      color: Colors.grey,
                      width: 2.0,
                    ),
                  ),
                ),
              ),
            ),
            // Container(
            //   margin: const EdgeInsets.only(top: 10.0, left: 10.0),
            //   child: const Text(
            //     "Departement",
            //     style: TextStyle(
            //       fontSize: 17,
            //       fontWeight: FontWeight.bold,
            //     ),
            //   ),
            // ),
            // Container(
            //     margin: const EdgeInsets.only(top: 10.0, left: 10.0),
            //     child: DropdownButtonHideUnderline(
            //       child: DropdownButton(
            //         items: dataDept.map((item) {
            //           return DropdownMenuItem(
            //             child: Text(item['nama_departement']),
            //             value: item['id'].toString(),
            //           );
            //         }).toList(),
            //         hint: const Text(
            //           "Please choose a Departement",
            //           textAlign: TextAlign.start,
            //           style: TextStyle(
            //               color: Colors.black,
            //               fontSize: 10,
            //               fontWeight: FontWeight.bold),
            //         ),
            //         onChanged: (String? newVal) {
            //           setState(() {
            //             selectDept = newVal;
            //             _dropdownError = null;
            //           });
            //         },
            //         value: selectDept,
            //       ),
            //     )),
            // _dropdownError == null
            //     ? SizedBox.shrink()
            //     : Text(
            //         _dropdownError ?? "",
            //         style: TextStyle(color: Colors.red),
            //       ),

            Container(
              margin: const EdgeInsets.only(top: 10.0, left: 10.0),
              child: const Text(
                "Dokumen Pendukung izin/sakit, kalau ada",
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 10.0, left: 10.0),
              child: DropdownButtonHideUnderline(
                child: DropdownButton(
                  focusColor: Colors.white,
                  value: cutiValue!.isNotEmpty ? cutiValue : "",
                  //elevation: 5,
                  style: const TextStyle(color: Colors.white),
                  iconEnabledColor: Colors.black,
                  items: const [
                    DropdownMenuItem(
                        child: Text("Cuti",
                            style: TextStyle(
                              color: Colors.black,
                            )),
                        value: "Cuti"),
                    DropdownMenuItem(
                      child: Text("Izin",
                          style: TextStyle(
                            color: Colors.black,
                          )),
                      value: "Izin",
                    ),
                    DropdownMenuItem(
                      child: Text("Sakit",
                          style: TextStyle(
                            color: Colors.black,
                          )),
                      value: "Sakit",
                    )
                  ],
                  hint: const Text(
                    "Please choose a langauage",
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 14,
                        fontWeight: FontWeight.w500),
                  ),
                  onChanged: (String? value) {
                    setState(() {
                      cutiValue = value!;
                    });
                  },
                ),
              ),
            ),

            Container(
              child: imageFile != null
                  ? Image.file(File(imageFile!.path), height: 80)
                  : Container(
                      margin: const EdgeInsets.only(top: 10.0, left: 10.0),
                      child: const Text(
                        'Foto Keterangan Cuti',
                        style: TextStyle(color: Colors.black, fontSize: 14),
                        textAlign: TextAlign.center,
                      )),
            ),
            Container(
              margin: const EdgeInsets.only(top: 10.0, left: 10.0),
              child: FloatingActionButton.extended(
                onPressed: myAlertImage,
                label: Text("Upload Foto"),
                // child: Text('Upload Foto'),
              ),
            ),

            Container(
              margin: const EdgeInsets.only(top: 10.0, left: 10.0),
              child: const Text(
                "Keperluan",
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 10.0, left: 10, right: 10),
              child: TextFormField(
                style: const TextStyle(color: Color(0xFF000000)),
                cursorColor: const Color(0xFF9b9b9b),
                keyboardType: TextInputType.text,
                controller: keperluan,
                decoration: InputDecoration(
                  fillColor: Colors.white,
                  hintText: "Keperluan",
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(5.0),
                    borderSide: const BorderSide(
                      color: Colors.grey,
                      width: 2.0,
                    ),
                  ),
                ),
              ),
            ),

            Container(
              margin: const EdgeInsets.only(top: 10.0, left: 10, right: 10),
              child: DateTimeField(
                validator: (value) {
                  if (value == null) {
                    return 'Please enter a date';
                  }
                  return null;
                },
                decoration: const InputDecoration(
                  hintText: "Tanggal Awal",
                  labelText: "Tanggal Awal",
                  // prefixText: _currency,
                  prefixIcon: Icon(
                    Icons.date_range,
                    color: Colors.grey,
                  ),
                ),
                format: format,
                controller: tanggalAwal,
                onShowPicker: (context, currentValue) {
                  return showDatePicker(
                      context: context,
                      firstDate: DateTime(1900),
                      initialDate: currentValue ?? DateTime.now(),
                      lastDate: DateTime(2100));
                },
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 10.0, left: 10, right: 10),
              child: DateTimeField(
                validator: (value) {
                  if (value == null) {
                    return 'Please enter a date';
                  }
                  return null;
                },
                decoration: new InputDecoration(
                  hintText: "Tanggal Akhir",
                  labelText: "Tanggal Akhir",
                  // prefixText: _currency,
                  prefixIcon: Icon(
                    Icons.date_range,
                    color: Colors.grey,
                  ),
                ),
                format: format,
                controller: tanggalAkhir,
                onShowPicker: (context, currentValue) {
                  return showDatePicker(
                      context: context,
                      firstDate: DateTime(1900),
                      initialDate: currentValue ?? DateTime.now(),
                      lastDate: DateTime(2100));
                },
              ),
            ),

            Container(
              margin: const EdgeInsets.only(top: 10.0, left: 10.0),
              child: const Text(
                "Durasi",
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 10.0, left: 10, right: 10),
              child: TextField(
                keyboardType: TextInputType.number,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.digitsOnly
                ],
                style: const TextStyle(color: Color(0xFF000000)),
                cursorColor: const Color(0xFF9b9b9b),
                //  keyboardType: TextInputType.text,
                controller: durasi,

                decoration: InputDecoration(
                  fillColor: Colors.white,
                  hintText: "Durasi",
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(5.0),
                    borderSide: const BorderSide(
                      color: Colors.grey,
                      width: 2.0,
                    ),
                  ),
                ),
              ),
            ),

            Container(
              margin: const EdgeInsets.only(top: 10.0, left: 10),
              child: simpan(),
            ),
            SizedBox(height: 10),
            //simpan(),
          ],
        ),
      ),
    );
  }
}
