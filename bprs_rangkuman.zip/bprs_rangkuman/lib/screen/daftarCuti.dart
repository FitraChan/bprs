import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:bprs/network_utils/api.dart';
import 'package:bprs/screen/menu.dart';
import 'package:bprs/screen/login.dart';
import 'package:bprs/model/karyawanCutiModel.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

class DaftarCuti extends StatefulWidget {
  DaftarCuti({
    Key? key,
  }) : super(key: key);

  @override
  _DaftarCutiState createState() => _DaftarCutiState();
}

class _DaftarCutiState extends State<DaftarCuti> {
  //  FirebaseMessaging messaging;

  String? name;
  String? _dropdownError;
  //String? noKaryawan;
  String? notificationText;

  bool _isFirstLoadRunning = false;
  File? imageFile = null;
  String status = '';
  String? cutiValue = 'Sakit';
  String errMessage = 'Error Uploading Image';
  bool loadingSave = false;
  String? idDepartement;
  String? jabatan;
  TextEditingController? namaKaryawan = TextEditingController();
  TextEditingController? noKaryawan = TextEditingController();
  TextEditingController? noHp = TextEditingController();
  TextEditingController? cuti = TextEditingController();
  TextEditingController? keperluan = TextEditingController();
  TextEditingController tanggalAwal = TextEditingController();
  TextEditingController tanggalAkhir = TextEditingController();
  TextEditingController? email = TextEditingController();
  TextEditingController? password = TextEditingController();
  List dataDept = [];

  List dataJab = [];

  List filteredNames = [];

  @override
  void initState() {
    // _loadUserData();

    fetchAlbum();
    super.initState();
  }

  List _posts = [];
  void fetchAlbum() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    var user = jsonDecode(localStorage.getString('user') ?? '');
    Map data = {
      'karyawan_id': user['id'],
    };

    setState(() {
      _isFirstLoadRunning = true;
    });

    try {
      // const String _url = 'http://192.168.5.10/bprs_api/public/api/show_cuti';

      String _url = 'https://absensi.mbcconsulting.id/api/show_cuti';
      final response = await Network().getData_post(data, _url);
      setState(() {
        _posts = json.decode(response.body);
      });
    } catch (e) {
      print('Something went wrong cuy');
    }

    setState(() {
      _isFirstLoadRunning = false;
    });
  }

// print("fail");
  // If the server did not return a 200 OK response,
  // then throw an exception.
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => Menu(
                      i: 0,
                    )),
          );
          return Future.value(true);
        },
        child: Scaffold(
          backgroundColor: Color.fromARGB(255, 247, 249, 250),
          body: SingleChildScrollView(
            child: Column(children: <Widget>[
              logo(),
              _isFirstLoadRunning
                  ? const Center(
                      child: CircularProgressIndicator(),
                    )
                  : dataProfil(),
            ]),
          ),
        ));
  }

  Container logo() {
    return Container(
      margin: const EdgeInsets.only(top: 25),
      width: 130,
      height: 40,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        // color: Colors.white,

        image: const DecorationImage(
          image: AssetImage('images/logo_bprs.jpg'),
          fit: BoxFit.fill,
        ),
      ),
    );
  }

  Container dataProfil() {
    final border = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10.0),
    );

    return Container(
      child: ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: _posts.length,
          itemBuilder: (BuildContext context, int index) {
            var inputFormat = DateFormat('yyyy-MM-dd');
            var inputDate =
                inputFormat.parse(_posts[index]['tanggal_mulai']!.toString());
            var outputFormat = DateFormat('dd/MM/yyyy');
            var outputDate = outputFormat.format(inputDate);

            //var
            var tanggalSelesaiFormat = DateFormat('yyyy-MM-dd');
            var inputTanggalSelesai = tanggalSelesaiFormat
                .parse(_posts[index]['tanggal_selesai']!.toString());
            var outputTanggalSelesaiFormat = DateFormat('dd/MM/yyyy');
            var outputTanggalSelesai =
                outputTanggalSelesaiFormat.format(inputTanggalSelesai);

            var tanggalPengajuanFormat = DateFormat('yyyy-MM-dd');
            var inputTanggalPengajuan = tanggalPengajuanFormat
                .parse(_posts[index]['created_at']!.toString());
            var outputTanggalPengajuanFormat = DateFormat('dd/MM/yyyy');
            var outputTanggalPengajuan =
                outputTanggalPengajuanFormat.format(inputTanggalPengajuan);

            final border = RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            );

            return Container(
                margin: const EdgeInsets.only(left: 14.0, right: 14),
                height: 170,
                child: Card(
                  shape: border,
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Container(
                          padding: const EdgeInsets.only(left: 20, right: 20),
                          child: const Text("Status Pengajuan",
                              style: TextStyle(
                                  fontSize: 17, fontWeight: FontWeight.bold))),
                      Container(
                        padding: const EdgeInsets.only(left: 20, right: 20),
                        child: Table(
                          // defaultVerticalAlignment:
                          //     TableCellVerticalAlignment.middle,
                          columnWidths: const {
                            0: FlexColumnWidth(2),
                            1: FlexColumnWidth(4),
                          },
                          //textDirection: TextDirection.ltr,
                          border: TableBorder.symmetric(
                              inside: BorderSide(
                                  width: 1, color: Colors.grey.shade300),
                              outside: BorderSide(
                                  width: 1, color: Colors.grey.shade300)),
                          defaultColumnWidth: const FixedColumnWidth(150),
                          defaultVerticalAlignment:
                              TableCellVerticalAlignment.middle,

                          children: [
                            TableRow(
                                decoration:
                                    BoxDecoration(color: Colors.grey[200]),
                                children: [
                                  Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: const [
                                        Text(
                                          'Tanggal Pengajuan',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ]),
                                  Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        // ignore: unrelated_type_equality_checks
                                        Text(outputTanggalPengajuan != Null
                                            ? outputTanggalPengajuan
                                            : "Null"),
                                      ]),
                                ]),
                            TableRow(children: [
                              const Text(
                                "Jenis Pengajuan",
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              Text(_posts[index]['jenis_absen'].toString()),
                            ]),
                            TableRow(
                                decoration:
                                    BoxDecoration(color: Colors.grey[200]),
                                children: [
                                  const Text(
                                    "Jumlah Hari",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  // ignore: unrelated_type_equality_checks
                                  Text(_posts[index]['durasi'].toString()),
                                ]),
                            TableRow(
                                decoration: BoxDecoration(color: Colors.white),
                                children: [
                                  const Text(
                                    "Tanggal Mulai",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  Text(outputDate != null ? outputDate : ''),
                                ]),
                            TableRow(
                                decoration:
                                    BoxDecoration(color: Colors.grey[200]),
                                children: [
                                  const Text(
                                    "Tanggal Selesai",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  Text(outputTanggalSelesai != null
                                      ? outputTanggalSelesai
                                      : ''),
                                ]),
                            TableRow(
                                decoration: BoxDecoration(color: Colors.white),
                                children: [
                                  const Text(
                                    "Keperluan",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  // ignore: unrelated_type_equality_checks
                                  Text(_posts[index]['keperluan'].toString()),
                                ]),
                            TableRow(
                                decoration:
                                    BoxDecoration(color: Colors.grey[200]),
                                children: [
                                  const Text(
                                    "Status",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  // ignore: unrelated_type_equality_checks
                                  Text(_posts[index]['status'].toString()),
                                ]),
                          ],
                        ),
                      ),
                    ],
                  ),
                ));
          }),
    );
  }
}
