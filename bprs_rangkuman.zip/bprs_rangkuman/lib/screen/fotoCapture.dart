import 'dart:io';
import 'dart:convert';

import 'package:bprs/screen/menu.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:maps_toolkit/maps_toolkit.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:bprs/screen/login.dart';
import 'package:bprs/network_utils/api.dart';
//import 'package:bprs/screen/abse.dart';

// ignore: must_be_immutable
class FotoCapture extends StatefulWidget {
  const FotoCapture({Key? key, required this.imagePath}) : super(key: key);
  final String imagePath;
  @override
  _FotoCaptureState createState() => _FotoCaptureState();
}

class _FotoCaptureState extends State<FotoCapture> {
  //  FirebaseMessaging messaging;
  File? imageFile = null;
  @override
  void initState() {
    // imageSelector();
    _getCurrentLocation();
    fetchAlbum();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => Menu(
                      i: 0,
                    )),
          );
          return Future.value(true);
        },
        child: Scaffold(
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              absen(),
              if (loadingLocation == true)
                Text(
                  "Checking Location.....",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              if (loadingLocation == false &&
                  jarak == true &&
                  widget.imagePath != "")
                startUpload(),
            ],
          ),
        ));
  }

  bool loadingLocation = false;
  Position? _currentPosition;
  String? _currentAddress;

  Container Lokasi() {
    return Container(
      margin: EdgeInsets.only(top: 8),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (_currentAddress != null) Text(_currentAddress!),
          Text(jauh),
        ],
      ),
    );
  }

  Future _getCurrentLocation() async {
    bool isLocationServiceEnabled = await Geolocator.isLocationServiceEnabled();

    setState(() {
      loadingLocation = true;
    });

    await Geolocator.checkPermission();
    await Geolocator.requestPermission();

    Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best)
        .then((Position position) {
      setState(() {
        _currentPosition = position;
      });

      _getAddressFromLatLng();
    }).catchError((e) {
      print("error....................................");
    });
  }

  bool jarak = false;

  String jauh = "";

  var jarakDoub;
  var longitude;
  var latitude;
  var lat;
  var lang;

  void fetchAlbum() async {
    SharedPreferences localStorage = await SharedPreferences.getInstance();
    var user = jsonDecode(localStorage.getString('user') ?? '');
    Map data = {
      'karyawan_id': user['id'],
    };
    // String _url = 'http://192.168.5.10/bprs_api/public/api/profil';
    String _url = 'https://absensi.mbcconsulting.id/api/profilPerusahaan';
    final response = await Network().getData_post(data, _url);

    var c = json.decode(response.body);

    if (response.statusCode == 200) {
      //print(c['pend']);
      // print(latlang);

      setState(() {
        lat = c['lat'];
        lang = c['lang'];
      });
    } else {
      throw Exception('Failed to load album');
    }
  }

  _getAddressFromLatLng() async {
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(
          _currentPosition!.latitude, _currentPosition!.longitude);

      Placemark place = placemarks[0];

      var latDouble = double.parse(lat);
      var langDouble = double.parse(lang);
      // final bankFajar = LatLng(-8.7123089, 115.1860254);
      final bankFajar = LatLng(latDouble, langDouble);
      final lokasi =
          LatLng(_currentPosition!.latitude, _currentPosition!.longitude);

      final distance =
          SphericalUtil.computeDistanceBetween(bankFajar, lokasi) / 1000.0;

      jarakDoub = double.parse(distance.toStringAsFixed(2));

      setState(() {
        _currentAddress =
            "${place.locality}, ${place.postalCode}, ${place.country},jarak = $jarakDoub km";

        if (distance >= 0 && distance <= 1) {
          jarak = true;
          //button();
          // jauh = "Anda Berada Di Areal Bank Fajar";
          longitude = _currentPosition!.longitude;
          latitude = _currentPosition!.latitude;
        } else if (distance <= 5) {
          jarak = true;
          //button();
          //   jauh = "Jarak Anda Dekat Dengan Bank Fajar";
          longitude = _currentPosition!.longitude;
          latitude = _currentPosition!.latitude;
        } else {
          jarak = true;
          //  jauh = " Terlalu Jauh Dari Bank Fajar";
          longitude = _currentPosition!.longitude;
          latitude = _currentPosition!.latitude;
        }

        loadingLocation = false;
      });
    } catch (e) {
      print(e);
    }
  }

  Container absen() {
    return Container(
        child: SafeArea(
      top: true,
      bottom: true,
      child: Align(
        alignment: Alignment.center,
        child: Column(
          children: <Widget>[
            Container(
              margin: const EdgeInsets.only(top: 20, left: 14.0, right: 14),
              height: 200,
              //margin: EdgeInsets.only(top: 20),
              child: widget.imagePath != null
                  ? Image.file(File(widget.imagePath), height: 80)
                  : header(),
            ),
          ],
        ),
      ),
    ));
  }

  Container header() {
    final border = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10.0),
    );

    return Container(
      width: double.infinity,
      height: 220,
      margin: const EdgeInsets.only(left: 14.0, right: 14),
      child: Card(
        shape: border,
        color: Colors.white,
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                padding: const EdgeInsets.only(left: 14.0, top: 12.0),
                child: const Text(
                  "Selamat Datang",
                  style: TextStyle(fontSize: 13),
                ),
              ),
              Container(
                child: Divider(
                  color: Colors.black26,
                  indent: 11,
                  endIndent: 11,
                ),
              ),
              Container(
                  child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Column(
                    children: [
                      GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              // ignore: unnecessary_new
                              new MaterialPageRoute(
                                  builder: (context) => Menu(
                                        i: 2,
                                      )),
                            );
                          },
                          child: Container(
                            margin: const EdgeInsets.only(top: 5),
                            height: 60,
                            width: 60,
                          )),
                      Container(
                        margin: const EdgeInsets.only(top: 7),
                        child: const Text(
                          "Profile",
                          style: TextStyle(fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                  Column(
                    children: [
                      Container(
                        margin: const EdgeInsets.only(top: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          // color: Colors.white,

                          image: const DecorationImage(
                            image: AssetImage('images/icon_riwayat_bprs.png'),
                            fit: BoxFit.fill,
                          ),
                        ),
                        height: 50,
                        width: 50,
                        child: GestureDetector(
                          // artinya direct ke halaman menu dulu trus baru di arahkan ke halaman yg di maksud berdasarkan index yg ada di widget menu
                          // paham cong.. kalau ga banyak dzikir....
                          onTap: () {
                            // Navigator.push(
                            //   context,
                            //    MaterialPageRoute(
                            //       builder: (context) => Riwayat()),
                            // );
                          },
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 7),
                        child: const Text(
                          "Riwayat",
                          style: TextStyle(fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ],
              ))
            ]),
      ),
    );
  }

  Container simpanGambar() {
    return Container(
      margin: EdgeInsets.only(top: 10),
      child: ConstrainedBox(
        constraints:
            BoxConstraints.tightFor(width: double.infinity, height: 50),
        child: FloatingActionButton.extended(
          heroTag: "btn1",
          icon: Icon(Icons.save),
          backgroundColor: Colors.blue,
          foregroundColor: Colors.white,
          label: Text(loadingSave ? 'Mohon Menunggu....' : 'Simpan'),
          onPressed: () {
            startUpload();
          },
        ),
      ),
    );
  }

  String status = '';
  // File? imageFile = null;
  String errMessage = 'Error Uploading Image';
  bool loadingSave = false;
  String? base64Image;

  final picker = ImagePicker();

  setStatus(String message) {
    setState(() {
      status = message;
    });
  }

  startUpload() {
    setStatus('Uploading Image...');

    setState(() {
      loadingSave = true;
    });

    upload();
  }

  upload() async {
    imageFile = File(widget.imagePath);

    base64Image = base64Encode(imageFile!.readAsBytesSync());

    //  base64Image = base64.encode(utf8.encode(widget.imagePath));
    // String fileName = widget.imagePath.split('/').last;
    String fileName = imageFile!.path.split('/').last;

    SharedPreferences localStorage = await SharedPreferences.getInstance();
    var user = jsonDecode(localStorage.getString('user') ?? '');

    //nim = user['str_nim'];
    Map data = {
      'base': base64Image,
      "image": fileName,
      'karyawan_id': user['id'],
      'lat': latitude,
      'long': longitude,
      'jarak': jarakDoub,
    };

    final String _url;
    var response;

    _url = 'https://absensi.mbcconsulting.id/api/save_konfirmation_pagi';
    response = await Network().getData_post(data, _url);

    //  print(response.body);
    if (response.statusCode == 200) {
      Alert(
        context: context,
        type: AlertType.success,
        title: _currentAddress ?? "",
        desc: "Selamat Data Has Been Saved",
        buttons: [
          DialogButton(
            child: const Text(
              "Ok",
              style: TextStyle(color: Colors.white, fontSize: 14),
            ),
            onPressed: () => Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (BuildContext context) => Menu(i: 0))),
          )
        ],
      ).show();
    } else {
      //throw Exception('Failed to load album');
      //  print(err);
      SharedPreferences localStorage = await SharedPreferences.getInstance();
      localStorage.remove('user');
      localStorage.remove('token');
      Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
    }
  }
}
